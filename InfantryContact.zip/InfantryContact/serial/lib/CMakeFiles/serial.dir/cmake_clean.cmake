file(REMOVE_RECURSE
  "CMakeFiles/serial.dir/src/impl/list_ports/list_ports_linux.cc.o"
  "CMakeFiles/serial.dir/src/impl/list_ports/list_ports_linux.cc.o.d"
  "CMakeFiles/serial.dir/src/impl/unix.cc.o"
  "CMakeFiles/serial.dir/src/impl/unix.cc.o.d"
  "CMakeFiles/serial.dir/src/serial.cc.o"
  "CMakeFiles/serial.dir/src/serial.cc.o.d"
  "libserial.a"
  "libserial.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang CXX)
  include(CMakeFiles/serial.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
